GitHub lin
https://github.com/dylanboyling/CST8211

Git hash for my version
a25d85a

Note: Ships are only randomized on startup. Ship randomization upon clicking 'Random' has not been 
implemented due to time contraints but is easy to do. Also, there is a bug when the history log 
becomes scrollable, when a language or dimension are selected it will resize the elements so that the bottom
half takes up most of the screen. Weird bug, will investigate and fix. Thanks for reading :) 