/**
 * These classes contain the game's logic and manage it. They track the state of the game and also verify guesses.
 */
package Game.Logic;
